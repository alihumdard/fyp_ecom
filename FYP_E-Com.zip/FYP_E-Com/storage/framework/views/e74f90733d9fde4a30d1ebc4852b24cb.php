<!-- partial:partials/_footer.html -->
<footer class="footer">
    <div class="d-sm-flex justify-content-center justify-content-sm-between">
        <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2022. All rights reserved.</span>
    </div>
</footer><?php /**PATH D:\1. PHP Projects\FYP_E-Com\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>