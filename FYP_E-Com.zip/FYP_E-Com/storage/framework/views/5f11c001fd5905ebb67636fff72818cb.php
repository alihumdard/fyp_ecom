<?php $__env->startSection('content'); ?>
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="row">
                <div class="col-md-12 grid-margin">
                    <div class="row">
                        <div class="col-12 col-xl-8 mb-4 mb-xl-0">
                            <h4 class="card-title">Categories</h4>
                        </div>
                        <div class="col-12 col-xl-4">
                            <div class="justify-content-end d-flex">
                                <div class="dropdown flex-md-grow-1 flex-xl-grow-0">
                                    <button class="btn btn-sm btn-light bg-white dropdown-toggle" type="button" id="dropdownMenuDate2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                    <i class="mdi mdi-calendar"></i> Today (10 Jan 2021)
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuDate2">
                                        <a class="dropdown-item" href="#">January - March</a>
                                        <a class="dropdown-item" href="#">March - June</a>
                                        <a class="dropdown-item" href="#">June - August</a>
                                        <a class="dropdown-item" href="#">August - November</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title"><?php echo e($title); ?></h4>


                            
                            
                            <?php if(Session::has('error_message')): ?> <!-- Check AdminController.php, updateAdminPassword() method -->
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <strong>Error:</strong> <?php echo e(Session::get('error_message')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <?php endif; ?>



                                
                            <?php if($errors->any()): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">

                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <?php endif; ?>



                            
                            
                            
                            <?php if(Session::has('success_message')): ?> <!-- Check AdminController.php, updateAdminPassword() method -->
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <strong>Success:</strong> <?php echo e(Session::get('success_message')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                

                            
                            <form class="forms-sample"   <?php if(empty($category['id'])): ?> action="<?php echo e(url('admin/add-edit-category')); ?>" <?php else: ?> action="<?php echo e(url('admin/add-edit-category/' . $category['id'])); ?>" <?php endif; ?>   method="post" enctype="multipart/form-data"> <?php echo csrf_field(); ?>  <!-- If the id is not passed in from the route, this measn 'Add a new Category', but if the id is passed in from the route, this means 'Edit the Category' --> <!-- Using the enctype="multipart/form-data" to allow uploading files (images) -->
                                <div class="form-group">
                                    <label for="category_name">Category Name</label>
                                    <input type="text" class="form-control" id="category_name" placeholder="Enter Category Name" name="category_name" <?php if(!empty($category['category_name'])): ?> value="<?php echo e($category['category_name']); ?>" <?php else: ?> value="<?php echo e(old('category_name')); ?>" <?php endif; ?>> 
                                </div>

                                
                                <div class="form-group">
                                    <label for="section_id">Select Section</label>
                                    <select name="section_id" id="section_id" class="form-control" style="color: #000">
                                        <option value="">Select Section</option>
                                        <?php $__currentLoopData = $getSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($section['id']); ?>"  <?php if(!empty($category['section_id']) && $category['section_id'] == $section['id']): ?> selected <?php endif; ?> ><?php echo e($section['name']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>



                                <div id="appendCategoriesLevel"> 
                                    <?php echo $__env->make('admin.categories.append_categories_level', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>



                                <div class="form-group">
                                    <label for="category_image">Category Image</label>
                                    <input type="file" class="form-control" id="category_image" name="category_image">
                                    
                                        <a target="_blank" href="<?php echo e(url('admin/images/photos/' . Auth::guard('admin')->user()->image)); ?>">View Image</a> <!-- We used    target="_blank"    to open the image in another separate page --> 
                                        <input type="hidden" name="current_category_image" value="<?php echo e(Auth::guard('admin')->user()->image); ?>"> <!-- to send the current admin image url all the time with all the requests --> 


                                    
                                    <?php if(!empty($category['category_image'])): ?>
                                        <a target="_blank" href="<?php echo e(url('front/images/category_images/' . $category['category_image'])); ?>">View Category Image</a>&nbsp;|&nbsp;
                                        <a href="JavaScript:void(0)" class="confirmDelete" module="category-image" moduleid="<?php echo e($category['id']); ?>">Delete Category Image</a>     
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="category_discount">Category Discount</label>
                                    <input type="text" class="form-control" id="category_discount" placeholder="Enter Category Discount" name="category_discount"   <?php if(!empty($category['category_discount'])): ?> value="<?php echo e($category['category_discount']); ?>" <?php else: ?> value="<?php echo e(old('category_discount')); ?>" <?php endif; ?> > 
                                </div>
                                <div class="form-group">
                                    <label for="description">Category Description</label>
                                    
                                    <textarea name="description" id="description" class="form-control" rows="3"><?php echo e($category['description']); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="url">Category URL</label>
                                    <input type="text" class="form-control" id="url" placeholder="Enter Category URL" name="url"   <?php if(!empty($category['url'])): ?> value="<?php echo e($category['url']); ?>" <?php else: ?> value="<?php echo e(old('url')); ?>" <?php endif; ?> > 
                                </div>
                                <div class="form-group">
                                    <label for="meta_title">Meta Title</label>
                                    <input type="text" class="form-control" id="meta_title" placeholder="Enter Meta Title" name="meta_title"   <?php if(!empty($category['meta_title'])): ?> value="<?php echo e($category['meta_title']); ?>" <?php else: ?> value="<?php echo e(old('meta_title')); ?>" <?php endif; ?> > 
                                </div>
                                <div class="form-group">
                                    <label for="meta_description">Meta Description</label>
                                    <input type="text" class="form-control" id="meta_description" placeholder="Enter Meta Description" name="meta_description"   <?php if(!empty($category['meta_description'])): ?> value="<?php echo e($category['meta_description']); ?>" <?php else: ?> value="<?php echo e(old('meta_description')); ?>" <?php endif; ?> > 
                                </div>
                                <div class="form-group">
                                    <label for="meta_keywords">Meta Keywords</label>
                                    <input type="text" class="form-control" id="meta_keywords" placeholder="Enter Meta Keywords" name="meta_keywords"   <?php if(!empty($category['meta_keywords'])): ?> value="<?php echo e($category['meta_keywords']); ?>" <?php else: ?> value="<?php echo e(old('meta_keywords')); ?>" <?php endif; ?> > 
                                </div>
                                <button type="submit" class="btn btn-primary mr-2">Submit</button>
                                <button type="reset"  class="btn btn-light">Cancel</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- content-wrapper ends -->
        <?php echo $__env->make('admin.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\1. PHP Projects\FYP_E-Com\resources\views/admin/categories/add_edit_category.blade.php ENDPATH**/ ?>