<?php $__env->startSection('content'); ?>
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="row">
                <div class="col-md-12 grid-margin">
                    <div class="row">
                        <div class="col-12 col-xl-8 mb-4 mb-xl-0">
                            <h4 class="card-title">Products</h4>
                        </div>
                        <div class="col-12 col-xl-4">
                            <div class="justify-content-end d-flex">
                                <div class="dropdown flex-md-grow-1 flex-xl-grow-0">
                                    <button class="btn btn-sm btn-light bg-white dropdown-toggle" type="button" id="dropdownMenuDate2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                    <i class="mdi mdi-calendar"></i> Today (10 Jan 2021)
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuDate2">
                                        <a class="dropdown-item" href="#">January - March</a>
                                        <a class="dropdown-item" href="#">March - June</a>
                                        <a class="dropdown-item" href="#">June - August</a>
                                        <a class="dropdown-item" href="#">August - November</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title"><?php echo e($title); ?></h4>


                            
                            
                            <?php if(Session::has('error_message')): ?> <!-- Check AdminController.php, updateAdminPassword() method -->
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <strong>Error:</strong> <?php echo e(Session::get('error_message')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>



                                
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">


                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>



                            
                            
                            
                            <?php if(Session::has('success_message')): ?> <!-- Check AdminController.php, updateAdminPassword() method -->
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <strong>Success:</strong> <?php echo e(Session::get('success_message')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                

                            


                            
                            <form class="forms-sample"   <?php if(empty($product['id'])): ?> action="<?php echo e(url('admin/add-edit-product')); ?>" <?php else: ?> action="<?php echo e(url('admin/add-edit-product/' . $product['id'])); ?>" <?php endif; ?>   method="post" enctype="multipart/form-data">  <!-- If the id is not passed in from the route, this measn 'Add a new Product', but if the id is passed in from the route, this means 'Edit the Product' --> <!-- Using the enctype="multipart/form-data" to allow uploading files (images) -->
                                <?php echo csrf_field(); ?>


                                
                                <div class="form-group">
                                    <label for="category_id">Select Category</label>
                                     
                                    <select name="category_id" id="category_id" class="form-control text-dark">
                                        <option value="">Select Category</option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                            <optgroup label="<?php echo e($section['name']); ?>"> 
                                                <?php $__currentLoopData = $section['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                                    <option value="<?php echo e($category['id']); ?>" <?php if(!empty($product['category_id'] == $category['id'])): ?> selected <?php endif; ?>><?php echo e($category['category_name']); ?></option> 
                                                    <?php $__currentLoopData = $category['sub_categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                                        <option value="<?php echo e($subcategory['id']); ?>" <?php if(!empty($product['category_id'] == $subcategory['id'])): ?> selected <?php endif; ?>>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;--&nbsp;<?php echo e($subcategory['category_name']); ?></option> 
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </optgroup>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </select>
                                </div>



                                 
                                <div class="loadFilters">
                                    <?php echo $__env->make('admin.filters.category_filters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>



                                <div class="form-group">
                                    <label for="brand_id">Select Brand</label>
                                    <select name="brand_id" id="brand_id" class="form-control text-dark">
                                        <option value="">Select Brand</option>
                                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($brand['id']); ?>" <?php if(!empty($product['brand_id'] == $brand['id'])): ?> selected <?php endif; ?>><?php echo e($brand['name']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="product_name">Product Name</label>
                                    <input type="text" class="form-control" id="product_name" placeholder="Enter Product Name" name="product_name" <?php if(!empty($product['product_name'])): ?> value="<?php echo e($product['product_name']); ?>" <?php else: ?> value="<?php echo e(old('product_name')); ?>" <?php endif; ?>>  
                                </div>
                                <div class="form-group">
                                    <label for="product_code">Product Code</label>
                                    <input type="text" class="form-control" id="product_code" placeholder="Enter Code" name="product_code" <?php if(!empty($product['product_code'])): ?> value="<?php echo e($product['product_code']); ?>" <?php else: ?> value="<?php echo e(old('product_code')); ?>" <?php endif; ?>>  
                                </div>
                                <div class="form-group">
                                    <label for="product_color">Product Color</label>
                                    <input type="text" class="form-control" id="product_color" placeholder="Enter Product Color" name="product_color" <?php if(!empty($product['product_color'])): ?> value="<?php echo e($product['product_color']); ?>" <?php else: ?> value="<?php echo e(old('product_color')); ?>" <?php endif; ?>>  
                                </div>
                                <div class="form-group">
                                    <label for="product_price">Product Price</label>
                                    <input type="text" class="form-control" id="product_price" placeholder="Enter Product Price" name="product_price" <?php if(!empty($product['product_price'])): ?> value="<?php echo e($product['product_price']); ?>" <?php else: ?> value="<?php echo e(old('product_price')); ?>" <?php endif; ?>> 
                                </div>
                                <div class="form-group">
                                    <label for="product_discount">Product Discount (%)</label>
                                    <input type="text" class="form-control" id="product_discount" placeholder="Enter Product Discount" name="product_discount" <?php if(!empty($product['product_discount'])): ?> value="<?php echo e($product['product_discount']); ?>" <?php else: ?> value="<?php echo e(old('product_discount')); ?>" <?php endif; ?>> 
                                </div>
                                <div class="form-group">
                                    <label for="product_weight">Product Weight (%)</label>
                                    <input type="text" class="form-control" id="product_weight" placeholder="Enter Product Weight" name="product_weight" <?php if(!empty($product['product_weight'])): ?> value="<?php echo e($product['product_weight']); ?>" <?php else: ?> value="<?php echo e(old('product_weight')); ?>" <?php endif; ?>> 
                                </div>



                                 
                                <div class="form-group">
                                    <label for="group_code">Group Code</label>
                                    <input type="text" class="form-control" id="group_code" placeholder="Enter Group Code" name="group_code"  <?php if(!empty($product['group_code'])): ?> value="<?php echo e($product['group_code']); ?>" <?php else: ?> value="<?php echo e(old('group_code')); ?>" <?php endif; ?>> 
                                </div>



                                <div class="form-group">
                                    <label for="product_image">Product Image (Recommended Size: 1000x1000)</label> 
                                    <input type="file" class="form-control" id="product_image" name="product_image">
                                    




                                    
                                    <?php if(!empty($product['product_image'])): ?>
                                        <a target="_blank" href="<?php echo e(url('front/images/product_images/large/' . $product['product_image'])); ?>">View Product Image</a>&nbsp;|&nbsp; 
                                        <a href="JavaScript:void(0)" class="confirmDelete" module="product-image" moduleid="<?php echo e($product['id']); ?>">Delete Product Image</a>     
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="product_video">Product Video (Recommended Size: Less than 2 MB)</label> 
                                    <input type="file" class="form-control" id="product_video" name="product_video">
                                    




                                    
                                    <?php if(!empty($product['product_video'])): ?>
                                        <a target="_blank" href="<?php echo e(url('front/videos/product_videos/' . $product['product_video'])); ?>">View Product Video</a>&nbsp;|&nbsp;
                                        <a href="JavaScript:void(0)" class="confirmDelete" module="product-video" moduleid="<?php echo e($product['id']); ?>">Delete Product Video</a>     
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="description">Product Description</label>
                                    <textarea name="description" id="description" class="form-control" rows="3"><?php echo e($product['description']); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="meta_title">Meta Title</label>
                                    <input type="text" class="form-control" id="meta_title" placeholder="Enter Meta Title" name="meta_title"   <?php if(!empty($product['meta_title'])): ?> value="<?php echo e($product['meta_title']); ?>" <?php else: ?> value="<?php echo e(old('meta_title')); ?>" <?php endif; ?> >  
                                </div>
                                <div class="form-group">
                                    <label for="meta_description">Meta Description</label>
                                    <input type="text" class="form-control" id="meta_description" placeholder="Enter Meta Description" name="meta_description"   <?php if(!empty($product['meta_description'])): ?> value="<?php echo e($product['meta_description']); ?>" <?php else: ?> value="<?php echo e(old('meta_description')); ?>" <?php endif; ?> >  
                                </div>
                                <div class="form-group">
                                    <label for="meta_keywords">Meta Keywords</label>
                                    <input type="text" class="form-control" id="meta_keywords" placeholder="Enter Meta Keywords" name="meta_keywords"   <?php if(!empty($product['meta_keywords'])): ?> value="<?php echo e($product['meta_keywords']); ?>" <?php else: ?> value="<?php echo e(old('meta_keywords')); ?>" <?php endif; ?> >  
                                </div>
                                <div class="form-group">
                                    <label for="is_featured">Featured Item (Yes/No)</label>
                                    <input type="checkbox" name="is_featured" id="is_featured" value="Yes" <?php if(!empty($product['is_featured']) && $product['is_featured'] == 'Yes'): ?> checked <?php endif; ?>>
                                </div>
                                <div class="form-group">
                                    <label for="is_bestseller">Best Seller Item (Yes/No)</label> 
                                    <input type="checkbox" name="is_bestseller" id="is_bestseller" value="Yes" <?php if(!empty($product['is_bestseller']) && $product['is_bestseller'] == 'Yes'): ?> checked <?php endif; ?>>
                                </div>
                                <button type="submit" class="btn btn-primary mr-2">Submit</button>
                                <button type="reset"  class="btn btn-light">Cancel</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- content-wrapper ends -->
        <?php echo $__env->make('admin.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\1. PHP Projects\FYP_E-Com\resources\views/admin/products/add_edit_product.blade.php ENDPATH**/ ?>