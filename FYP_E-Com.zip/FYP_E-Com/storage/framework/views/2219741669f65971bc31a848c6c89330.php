 


<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <tr><td>Dear <?php echo e($name); ?>!</td></tr>
        <tr><td>&nbsp;<br><br></td></tr>
        <tr><td>Your Vendor Account has been approved. Now you can login and add products.</td></tr>
        <tr><td>&nbsp;<br><br></td></tr>
        <tr><td>Your Vendor Account Details are as below :-<br></td></tr>
        <tr><td>&nbsp;<br></td></tr>
        <tr><td>Name: <?php echo e($name); ?></td></tr>
        <tr><td>&nbsp;<br></td></tr>
        <tr><td>Mobile: <?php echo e($mobile); ?></td></tr>
        <tr><td>&nbsp;<br></td></tr>
        <tr><td>Email: <?php echo e($email); ?></td></tr>
        <tr><td>&nbsp;<br></td></tr>
        <tr><td>Password: ***** (as chosen by you)</td></tr>
        <tr><td>&nbsp;<br><br></td></tr>
        <tr><td>Thanks & Regards,</td></tr>
        <tr><td>&nbsp;<br></td></tr>
        <tr><td>Multi-vendor E-commerce Application</td></tr>
    </body>
</html><?php /**PATH D:\1. PHP Projects\FYP_E-Com\resources\views/emails/vendor_approved.blade.php ENDPATH**/ ?>