<?php $__env->startSection('content'); ?>
    <!-- Page Introduction Wrapper -->
    <div class="page-style-a">
        <div class="container">
            <div class="page-intro">
                <h2>Checkout</h2>
                <ul class="bread-crumb">
                    <li class="has-separator">
                        <i class="ion ion-md-home"></i>
                        <a href="index.html">Home</a>
                    </li>
                    <li class="is-marked">
                        <a href="checkout.html">Checkout</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Page Introduction Wrapper /- -->
    <!-- Checkout-Page -->
    <div class="page-checkout u-s-p-t-80">
        <div class="container">

            
            
            <?php if(Session::has('error_message')): ?> <!-- Check AdminController.php, updateAdminPassword() method -->
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong>Error:</strong> <?php echo e(Session::get('error_message')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>



                <div class="row">
                    <div class="col-lg-12 col-md-12">

                        <!-- Second Accordion /- -->

                        <div class="row">
                            <!-- Billing-&-Shipping-Details -->
                            <div class="col-lg-6" id="deliveryAddresses"> 



                                
                                
                                <?php echo $__env->make('front.products.delivery_addresses', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



                            </div>
                            <!-- Billing-&-Shipping-Details /- -->
                            <!-- Checkout -->
                            <div class="col-lg-6">



                                
                                <form name="checkoutForm" id="checkoutForm" action="<?php echo e(url('/checkout')); ?>" method="post">
                                    <?php echo csrf_field(); ?> 


                                    
                                    
                                    <?php if(count($deliveryAddresses) > 0): ?>  

                                        <h4 class="section-h4">Delivery Addresses</h4>

                                        <?php $__currentLoopData = $deliveryAddresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="control-group" style="float: left; margin-right: 5px">
                                                  
                                                <input type="radio" id="address<?php echo e($address['id']); ?>" name="address_id" value="<?php echo e($address['id']); ?>" shipping_charges="<?php echo e($address['shipping_charges']); ?>" total_price="<?php echo e($total_price); ?>" coupon_amount="<?php echo e(\Illuminate\Support\Facades\Session::get('couponAmount')); ?>" codpincodeCount="<?php echo e($address['codpincodeCount']); ?>" prepaidpincodeCount="<?php echo e($address['prepaidpincodeCount']); ?>">  
                                            </div>
                                            <div>
                                                <label class="control-label" for="address<?php echo e($address['id']); ?>">
                                                    <?php echo e($address['name']); ?>, <?php echo e($address['address']); ?>, <?php echo e($address['city']); ?>, <?php echo e($address['state']); ?>, <?php echo e($address['country']); ?> (<?php echo e($address['mobile']); ?>)
                                                </label>
                                                <a href="javascript:;" data-addressid="<?php echo e($address['id']); ?>" class="removeAddress" style="float: right; margin-left: 10px">Remove</a>  
                                                <a href="javascript:;" data-addressid="<?php echo e($address['id']); ?>" class="editAddress"   style="float: right"                   >Edit</a>    
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <br>
                                    <?php endif; ?> 


                                    <h4 class="section-h4">Your Order</h4>
                                    <div class="order-table">
                                        <table class="u-s-m-b-13">
                                            <thead>
                                                <tr>
                                                    <th>Product</th>
                                                    <th>Total</th>
                                                </tr>
                                            </thead>
                                            <tbody>


                                                
                                                
                                                <?php $total_price = 0 ?>

                                                <?php $__currentLoopData = $getCartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                    <?php
                                                        $getDiscountAttributePrice = \App\Models\Product::getDiscountAttributePrice($item['product_id'], $item['size']); // from the `products_attributes` table, not the `products` table
                                                        // dd($getDiscountAttributePrice);
                                                    ?>


                                                    <tr>
                                                        <td>
                                                            <a href="<?php echo e(url('product/' . $item['product_id'])); ?>">
                                                                <img width="50px" src="<?php echo e(asset('front/images/product_images/small/' . $item['product']['product_image'])); ?>" alt="Product">
                                                                <h6 class="order-h6"><?php echo e($item['product']['product_name']); ?>

                                                                <br>
                                                                <?php echo e($item['size']); ?>/<?php echo e($item['product']['product_color']); ?></h6>
                                                            </a>
                                                            <span class="order-span-quantity">x <?php echo e($item['quantity']); ?></span>
                                                        </td>
                                                        <td>
                                                            <h6 class="order-h6">EGP<?php echo e($getDiscountAttributePrice['final_price'] * $item['quantity']); ?></h6> 
                                                        </td>
                                                    </tr>


                                                    
                                                    
                                                    <?php $total_price = $total_price + ($getDiscountAttributePrice['final_price'] * $item['quantity']) ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                <tr>
                                                    <td>
                                                        <h3 class="order-h3">Subtotal</h3>
                                                    </td>
                                                    <td>
                                                        <h3 class="order-h3">EGP<?php echo e($total_price); ?></h3>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <h6 class="order-h6">Shipping Charges</h6>
                                                    </td>
                                                    <td>
                                                        <h6 class="order-h6">
                                                            <span class="shipping_charges">EGP0</span>
                                                        </h6>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <h6 class="order-h6">Coupon Discount</h6>
                                                    </td>
                                                    <td>
                                                        <h6 class="order-h6">
                                                            
                                                            <?php if(\Illuminate\Support\Facades\Session::has('couponAmount')): ?> 
                                                                <span class="couponAmount">EGP<?php echo e(\Illuminate\Support\Facades\Session::get('couponAmount')); ?></span>
                                                            <?php else: ?>
                                                                EGP0
                                                            <?php endif; ?>
                                                        </h6>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <h3 class="order-h3">Grand Total</h3>
                                                    </td>
                                                    <td>
                                                        <h3 class="order-h3">
                                                            <strong class="grand_total">EGP<?php echo e($total_price - \Illuminate\Support\Facades\Session::get('couponAmount')); ?></strong>  
                                                        </h3>
                                                    </td>
                                                </tr>


                                            </tbody>
                                        </table>
                                        <div class="u-s-m-b-13 codMethod"> 
                                            <input type="radio" class="radio-box" name="payment_gateway" id="cash-on-delivery" value="COD">
                                            <label class="label-text" for="cash-on-delivery">Cash on Delivery</label>
                                        </div>
                                        <div class="u-s-m-b-13 prepaidMethod"> 
                                            <input type="radio" class="radio-box" name="payment_gateway" id="paypal" value="Paypal">
                                            <label class="label-text" for="paypal">PayPal</label>
                                        </div>


                                        
                                        <div class="u-s-m-b-13 prepaidMethod"> 
                                            <input type="radio" class="radio-box" name="payment_gateway" id="iyzipay" value="iyzipay">
                                            <label class="label-text" for="iyzipay">iyzipay</label>
                                        </div>


                                        <div class="u-s-m-b-13">
                                            <input type="checkbox" class="check-box" id="accept" name="accept" value="Yes" title="Please agree to T&C">
                                            <label class="label-text no-color" for="accept">I’ve read and accept the
                                                <a href="terms-and-conditions.html" class="u-c-brand">terms & conditions</a>
                                            </label>
                                        </div>
                                        <button type="submit" id="placeOrder" class="button button-outline-secondary">Place Order</button> 
                                    </div>
                                </form>


                            </div>
                            <!-- Checkout /- -->
                        </div>

                    </div>
                </div>


        </div>
    </div>
    <!-- Checkout-Page /- -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel-multi-vendor-e-commerce-application-main\resources\views/front/products/checkout.blade.php ENDPATH**/ ?>